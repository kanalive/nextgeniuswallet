#import <Cordova/CDVPlugin.h>

@interface IonicCordovaCommon : CDVPlugin

- (void)getAppInfo:(CDVInvokedUrlCommand*)command;

@end