#import <Foundation/Foundation.h>

extern NSString *const NO_DEPLOY_LABEL;
extern NSString *const NOTHING_TO_IGNORE;
extern NSString *const PLUGIN_VERSION;
